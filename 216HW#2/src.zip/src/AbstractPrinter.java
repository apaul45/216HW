/**
 * DO NOT CHANGE THIS CODE
 */
public abstract class AbstractPrinter<T> {
    abstract void print(T t);
}